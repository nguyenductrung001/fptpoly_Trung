package com.pt15305ud.service;

import java.util.List;

import com.pt15305ud.entity.Category;

public interface CategoryService {

	List<Category> findAll();

}
