package com.pt15305ud.service;

import com.pt15305ud.entity.Account;

public interface AccountService {

	Account findById(String username);
}
