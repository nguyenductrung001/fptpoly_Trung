app.controller("authority-ctrl", function($scope,$http,$location){
	alert("PQ")
})