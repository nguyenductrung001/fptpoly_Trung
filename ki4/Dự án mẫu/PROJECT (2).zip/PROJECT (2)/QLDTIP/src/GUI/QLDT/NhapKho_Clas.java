/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI.QLDT;

/**
 *
 * @author Truong Dep Zai
 */
public class NhapKho_Clas {
    public  String TenDT,MaDT;
    public double SoLuong,GiaNhap;

    public NhapKho_Clas() {
    }

    public String getTenDT() {
        return TenDT;
    }

    public void setTenDT(String TenDT) {
        this.TenDT = TenDT;
    }

    public String getMaDT() {
        return MaDT;
    }

    public void setMaDT(String MaDT) {
        this.MaDT = MaDT;
    }

    public double getSoLuong() {
        return SoLuong;
    }

    public void setSoLuong(double SoLuong) {
        this.SoLuong = SoLuong;
    }

    public double getGiaNhap() {
        return GiaNhap;
    }

    public void setGiaNhap(double GiaNhap) {
        this.GiaNhap = GiaNhap;
    }
    
}
