/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI.QLDT;

/**
 *
 * @author Truong Dep Zai
 */
public class DienThoai_Class {
    public String MaDT,TenDT,Ram,BoNHoTrong,Details,TheSim,MauSac,CamTruoc,CamSau,ManHinh,HeDieuHanh,TSKT;
    public double GiaBan,GiaNhap;
    public  int SoLuong;

    public DienThoai_Class() {
    }

    public String getMaDT() {
        return MaDT;
    }

    public void setMaDT(String MaDT) {
        this.MaDT = MaDT;
    }

    public String getTenDT() {
        return TenDT;
    }

    public void setTenDT(String TenDT) {
        this.TenDT = TenDT;
    }

    public String getRam() {
        return Ram;
    }

    public void setRam(String Ram) {
        this.Ram = Ram;
    }

    public String getBoNHoTrong() {
        return BoNHoTrong;
    }

    public void setBoNHoTrong(String BoNHoTrong) {
        this.BoNHoTrong = BoNHoTrong;
    }

    public String getDetails() {
        return Details;
    }

    public void setDetails(String Details) {
        this.Details = Details;
    }

    public String getTheSim() {
        return TheSim;
    }

    public void setTheSim(String TheSim) {
        this.TheSim = TheSim;
    }

    public String getMauSac() {
        return MauSac;
    }

    public void setMauSac(String MauSac) {
        this.MauSac = MauSac;
    }

    public String getCamTruoc() {
        return CamTruoc;
    }

    public void setCamTruoc(String CamTruoc) {
        this.CamTruoc = CamTruoc;
    }

    public String getCamSau() {
        return CamSau;
    }

    public void setCamSau(String CamSau) {
        this.CamSau = CamSau;
    }

    public String getManHinh() {
        return ManHinh;
    }

    public void setManHinh(String ManHinh) {
        this.ManHinh = ManHinh;
    }

    public String getHeDieuHanh() {
        return HeDieuHanh;
    }

    public void setHeDieuHanh(String HeDieuHanh) {
        this.HeDieuHanh = HeDieuHanh;
    }

    public String getTSKT() {
        return TSKT;
    }

    public void setTSKT(String TSKT) {
        this.TSKT = TSKT;
    }

    public double getGiaBan() {
        return GiaBan;
    }

    public void setGiaBan(double GiaBan) {
        this.GiaBan = GiaBan;
    }

    public double getGiaNhap() {
        return GiaNhap;
    }

    public void setGiaNhap(double GiaNhap) {
        this.GiaNhap = GiaNhap;
    }

    public int getSoLuong() {
        return SoLuong;
    }

    public void setSoLuong(int SoLuong) {
        this.SoLuong = SoLuong;
    }

    
    

  
     
}
