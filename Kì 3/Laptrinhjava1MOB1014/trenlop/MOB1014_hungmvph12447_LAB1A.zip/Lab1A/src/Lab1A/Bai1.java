package Lab1A;

/**
 * Bai1 nhap vao ho ten va diem tb roi in ra man hinh
 */
public class Bai1 {

    public static void main(String[] args) {
    System.out.println("Moi Ban Nhap:");
    System.out.println("Ho ten:");
    java.util.Scanner s = new java.util.Scanner(System.in);
    String ten = s.nextLine();
    System.out.println("Diem TB:");
    double diemtb = Double.parseDouble(s.nextLine());
    System.out.printf("%s %.1f diem",ten,diemtb);
    }
}