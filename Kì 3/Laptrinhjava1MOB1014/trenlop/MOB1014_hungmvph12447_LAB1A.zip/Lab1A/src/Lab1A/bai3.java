package Lab1A;

import java.util.Scanner;

/**
 * bai3 nhap canh cua khoi lap phuong va tinh the tich
 */
public class bai3 {

    public static void main(String[] args) {
        System.out.println("moi ban nhap");
        Scanner s = new Scanner(System.in);
        System.out.print("a: ");
        double a = Double.parseDouble(s.nextLine());
        double thetich = Math.pow(a, 3);
        System.out.printf("the tich: %.1f",thetich);
    }
}