package Lab1A;

import java.util.Scanner;

/**
 * Bai2 tinh chu vi dien tich a canh ngan nhat cua hinh chu nhat
 */
public class Bai2 {

    public static void main(String[] args) {
        System.out.println("moi ban nhap");
        Scanner s = new Scanner(System.in);
        double a, b;
        System.out.print("a:");
        a = Double.parseDouble(s.nextLine());
        System.out.print("b:");
        b = Double.parseDouble(s.nextLine());
        double cv, dt, ngannhat;
        cv = (a + b) * 2;
        dt = a * b;
        ngannhat = Math.min(a, b);
        System.out.printf("chu vi: %.1f\ndien tich: %.1f\ncanh ngan nhat: %.1f", cv, dt, ngannhat);
    }
}