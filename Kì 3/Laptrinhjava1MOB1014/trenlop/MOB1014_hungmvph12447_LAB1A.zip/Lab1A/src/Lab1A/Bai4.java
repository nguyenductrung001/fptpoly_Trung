package Lab1A;

import java.util.Scanner;

/**
 * Bai4 nhap cac he so cua pt bac 2 va tinh can delta
 */
public class Bai4 {

    public static void main(String[] args) {
        System.out.println("moi ban nhap");
        Scanner s = new Scanner(System.in);
        double a, b, c;
        System.out.print("a: ");
        a = Double.parseDouble(s.nextLine());
        System.out.print("b: ");
        b = Double.parseDouble(s.nextLine());
        System.out.print("c: ");
        c = Double.parseDouble(s.nextLine());
        double delta;
        delta = Math.pow(b, 2) - 4 * a * c;
        if (delta >= 0) {
            double candelta = Math.sqrt(delta);
            System.out.printf("can delta: %.1f", candelta);
        } else {
            System.out.println("Delta nho hon 0");
        }
    }
}