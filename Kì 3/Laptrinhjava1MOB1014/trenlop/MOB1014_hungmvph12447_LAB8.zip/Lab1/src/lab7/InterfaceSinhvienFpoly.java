package lab7;

public interface InterfaceSinhvienFpoly {
    public double getDiemTB();

    public void nhap();

    public void xuat();
}